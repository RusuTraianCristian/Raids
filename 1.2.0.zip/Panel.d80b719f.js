// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles

// eslint-disable-next-line no-global-assign
parcelRequire = (function (modules, cache, entry, globalName) {
  // Save the require from previous bundle to this closure if any
  var previousRequire = typeof parcelRequire === 'function' && parcelRequire;
  var nodeRequire = typeof require === 'function' && require;

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire = typeof parcelRequire === 'function' && parcelRequire;
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error('Cannot find module \'' + name + '\'');
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;

      var module = cache[name] = new newRequire.Module(name);

      modules[name][0].call(module.exports, localRequire, module, module.exports, this);
    }

    return cache[name].exports;

    function localRequire(x){
      return newRequire(localRequire.resolve(x));
    }

    function resolve(x){
      return modules[name][1][x] || x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;

  for (var i = 0; i < entry.length; i++) {
    newRequire(entry[i]);
  }

  if (entry.length) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(entry[entry.length - 1]);

    // CommonJS
    if (typeof exports === "object" && typeof module !== "undefined") {
      module.exports = mainExports;

    // RequireJS
    } else if (typeof define === "function" && define.amd) {
     define(function () {
       return mainExports;
     });

    // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }

  // Override the current require with this new one
  return newRequire;
})({225:[function(require,module,exports) {

},{}],8:[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = require("react");

var _react2 = _interopRequireDefault(_react);

require("./Panel.css");

var _reactRedux = require("react-redux");

var _index = require("../../store/index");

var _index2 = _interopRequireDefault(_index);

var _actionTypes = require("../../constants/action-types");

var _actions = require("../../actions");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Panel = function (_React$Component) {
    _inherits(Panel, _React$Component);

    function Panel(props) {
        _classCallCheck(this, Panel);

        var _this = _possibleConstructorReturn(this, (Panel.__proto__ || Object.getPrototypeOf(Panel)).call(this, props));

        _this.state = _index2.default.getState();
        return _this;
    } // end of constructor

    _createClass(Panel, [{
        key: "componentDidMount",
        value: function componentDidMount() {

            window.Twitch.ext.onContext(function (context) {});

            window.Twitch.ext.actions.requestIdShare();

            window.Twitch.ext.onAuthorized(function (auth) {});

            window.Twitch.ext.onError(function (e) {
                return void 0;
            });

            window.Twitch.ext.onAuthorized(function () {
                var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(auth) {
                    var twitchFetch = function () {
                        var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(url) {
                            var headers, options, response, data;
                            return regeneratorRuntime.wrap(function _callee$(_context) {
                                while (1) {
                                    switch (_context.prev = _context.next) {
                                        case 0:
                                            headers = new Headers({
                                                'Client-ID': auth.clientId,
                                                'Accept': "application/vnd.twitchtv.v5+json",
                                                'Authorization': "Bearer " + auth.token
                                            });
                                            options = { method: "GET", headers: headers };
                                            _context.prev = 2;
                                            _context.next = 5;
                                            return fetch(url, options);

                                        case 5:
                                            response = _context.sent;
                                            _context.next = 8;
                                            return response.json();

                                        case 8:
                                            data = _context.sent;
                                            return _context.abrupt("return", data);

                                        case 12:
                                            _context.prev = 12;
                                            _context.t0 = _context["catch"](2);

                                        case 14:
                                            return _context.abrupt("return", undefined);

                                        case 15:
                                        case "end":
                                            return _context.stop();
                                    }
                                }
                            }, _callee, this, [[2, 12]]);
                        }));

                        return function twitchFetch(_x2) {
                            return _ref2.apply(this, arguments);
                        };
                    }();

                    var getDisplay = function () {
                        var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(userId) {
                            var url, result;
                            return regeneratorRuntime.wrap(function _callee2$(_context2) {
                                while (1) {
                                    switch (_context2.prev = _context2.next) {
                                        case 0:
                                            url = "https://api.twitch.tv/helix/users?id=" + userId;
                                            _context2.next = 3;
                                            return twitchFetch(url);

                                        case 3:
                                            result = _context2.sent;
                                            return _context2.abrupt("return", result);

                                        case 5:
                                        case "end":
                                            return _context2.stop();
                                    }
                                }
                            }, _callee2, this);
                        }));

                        return function getDisplay(_x3) {
                            return _ref3.apply(this, arguments);
                        };
                    }();

                    var userId, token, userData, displayName, login;
                    return regeneratorRuntime.wrap(function _callee3$(_context3) {
                        while (1) {
                            switch (_context3.prev = _context3.next) {
                                case 0:
                                    userId = auth.userId;
                                    token = auth.token;
                                    _context3.next = 4;
                                    return getDisplay(auth.channelId);

                                case 4:
                                    userData = _context3.sent;
                                    displayName = userData.data[0].display_name;
                                    login = userData.data[0].login;


                                    document.getElementById('authinfo').innerHTML = "Hello there, " + displayName + "! Thank you for using our awesome extension. Your channel ID is: " + auth.channelId + " and user's ID is " + auth.userId;

                                case 8:
                                case "end":
                                    return _context3.stop();
                            }
                        }
                    }, _callee3, this);
                }));

                return function (_x) {
                    return _ref.apply(this, arguments);
                };
            }());

            // Bits

            // gets all Bits products

            window.Twitch.ext.bits.getProducts().then(function (products) {

                document.getElementById('raid500').innerHTML = products[3].cost.amount + " Bits";
                document.getElementById('raid1000').innerHTML = products[0].cost.amount + " Bits";
                document.getElementById('raid2000').innerHTML = products[2].cost.amount + " Bits";
                document.getElementById('raid5000').innerHTML = products[4].cost.amount + " Bits";
                document.getElementById('raid10000').innerHTML = products[1].cost.amount + " Bits";

                var mappedProducts = products.map(function (number) {
                    return _react2.default.createElement(
                        "li",
                        null,
                        number
                    );
                });
            }); // end of products list
        } // end of componentDidMount

        // calls a Bits product based on Sku (id arg)

    }, {
        key: "buyRaid",
        value: function buyRaid(id) {
            window.Twitch.ext.bits.getProducts().then(function (products) {
                var productSku = products[id].sku;
                Twitch.ext.bits.useBits(productSku);
            });
        } // end of use Bits function

    }, {
        key: "render",
        value: function render() {
            return _react2.default.createElement(
                _react2.default.Fragment,
                null,
                _react2.default.createElement(
                    "div",
                    { id: "Panel" },
                    _react2.default.createElement(
                        "div",
                        { id: "price" },
                        "Stream ends in: ",
                        this.state.price
                    ),
                    _react2.default.createElement("div", { id: "authinfo" }),
                    _react2.default.createElement("div", { id: "raid500", onClick: this.buyRaid.bind(this, 3) }),
                    _react2.default.createElement("div", { id: "raid1000", onClick: this.buyRaid.bind(this, 0) }),
                    _react2.default.createElement("div", { id: "raid2000", onClick: this.buyRaid.bind(this, 2) }),
                    _react2.default.createElement("div", { id: "raid5000", onClick: this.buyRaid.bind(this, 4) }),
                    _react2.default.createElement("div", { id: "raid10000", onClick: this.buyRaid.bind(this, 1) })
                )
            ); // end of return
        } // end of render

    }]);

    return Panel;
}(_react2.default.Component); // end of component

// stores persistent information in localStorage whenever an action is dispatched

_index2.default.subscribe(function () {
    localStorage.setItem('reduxState', JSON.stringify(_index2.default.getState()));
});

// exports the component

exports.default = Panel;
},{"react":18,"./Panel.css":225,"react-redux":19,"../../store/index":10,"../../constants/action-types":224,"../../actions":323}]},{},[8], null)
//# sourceMappingURL=Panel.cf84c219.map